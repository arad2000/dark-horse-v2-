"""Credit-based billing service for Dark Horse V2.

Rules:
- Free users receive exactly one non-expiring test credit.
- ``pack_3_tests`` adds exactly 3 credits after verified payment.
- Credit consumption is atomic at the database level.
- Payment verification is provider-agnostic; real ZarinPal and mock providers
  can implement the same interface in parallel.
- Optional ``BILLING_FREE_MODE=true`` disables credit limits until launch.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Protocol
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session

from billing_models import Entitlement, Order, Payment, PaymentEvent, PremiumPlan, User
from referral_service import snapshot_order_referral
from referral_commission_service import accrue_commission, snapshot_order_owner

FREE_PLAN_CODE = "free_1_test"
PACK_3_TESTS_CODE = "pack_3_tests"
PACK_3_PRICE_RIAL = 2_490_000
PACK_3_CREDITS = 3
FREE_CREDITS = 1
FREE_MODE_CREDITS = 999_999


def is_billing_free_mode() -> bool:
    """Temporary unlimited-test mode until commercial launch is complete."""
    return os.getenv("BILLING_FREE_MODE", "").strip().lower() in {"1", "true", "yes", "on"}


class PaymentProvider(Protocol):
    name: str

    def request_payment(self, *, amount_rial: int, order_public_id: str, callback_url: str) -> dict: ...
    def verify_payment(self, *, amount_rial: int, authority: str) -> dict: ...


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def ensure_free_entitlement(db: Session, user_id: int) -> Entitlement:
    """Provision free credits once, idempotently.

    In normal mode grants 1 credit. In BILLING_FREE_MODE grants a large pool and
    top-ups existing free entitlements so users are never blocked.
    """
    free_plan = db.scalar(select(PremiumPlan).where(PremiumPlan.code == FREE_PLAN_CODE))
    if free_plan is None:
        raise ValueError("free plan is not configured")

    credits = FREE_MODE_CREDITS if is_billing_free_mode() else FREE_CREDITS

    existing = db.scalar(
        select(Entitlement).where(
            Entitlement.user_id == user_id,
            Entitlement.plan_id == free_plan.id,
            Entitlement.source == "free",
        )
    )
    if existing is not None:
        if is_billing_free_mode() and int(existing.credits_remaining or 0) < credits:
            existing.credits_remaining = credits
            existing.credits_granted = max(int(existing.credits_granted or 0), credits)
            existing.status = "active"
            db.flush()
        return existing

    entitlement = Entitlement(
        user_id=user_id,
        plan_id=free_plan.id,
        source="free",
        credits_granted=credits,
        credits_remaining=credits,
        starts_at=utcnow(),
        expires_at=None,
        status="active",
    )
    db.add(entitlement)
    db.flush()
    return entitlement


def create_pack_order(db: Session, user_id: int, plan_code: str = PACK_3_TESTS_CODE) -> Order:
    """Create an order using server-side plan pricing/credit values only."""
    user = db.get(User, user_id)
    if user is None:
        raise ValueError("unknown user")
    plan = db.scalar(select(PremiumPlan).where(PremiumPlan.code == plan_code, PremiumPlan.is_active.is_(True)))
    if plan is None:
        raise ValueError("unknown or inactive plan")
    if plan_code != PACK_3_TESTS_CODE or plan.credits_granted != PACK_3_CREDITS:
        raise ValueError("unexpected credit-pack configuration")

    return Order(
        public_id=str(uuid4()),
        user_id=user_id,
        plan_id=plan.id,
        amount_minor=plan.price_minor,
        currency=plan.currency,
        status="pending",
    )


def _append_order_id(callback_url: str, order_public_id: str) -> str:
    """Append the server-generated order id without dropping existing query args."""
    parts = urlsplit(callback_url)
    query = parse_qsl(parts.query, keep_blank_values=True)
    query = [(key, value) for key, value in query if key != "order_id"]
    query.append(("order_id", order_public_id))
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))


def initiate_payment(
    db: Session,
    user_id: int,
    provider: PaymentProvider,
    callback_url: str,
    plan_code: str = PACK_3_TESTS_CODE,
) -> tuple[Order, Payment, dict]:
    """Create pending order/payment and request provider authority."""
    order = create_pack_order(db, user_id, plan_code)
    db.add(order)
    db.flush()

    provider_callback_url = _append_order_id(callback_url, order.public_id)
    response = provider.request_payment(
        amount_rial=order.amount_minor,
        order_public_id=order.public_id,
        callback_url=provider_callback_url,
    )
    authority = response.get("authority")
    if not authority:
        raise ValueError("payment provider did not return authority")

    payment = Payment(
        order_id=order.id,
        provider=provider.name,
        provider_request_id=str(response.get("request_id")) if response.get("request_id") is not None else None,
        provider_authority=str(authority),
        amount_minor=order.amount_minor,
        currency=order.currency,
        status="initiated",
    )
    db.add(payment)
    db.flush()
    return order, payment, response


def verify_and_grant(
    db: Session,
    payment_public_id: int,
    provider: PaymentProvider,
    authority: str,
    event_key: str,
    raw_callback: dict | None = None,
) -> Entitlement:
    """Verify payment and grant exactly plan.credits_granted in one transaction.

    A repeated callback for an already-verified payment is idempotent even when
    the gateway retries it with a different event key. The verified payment/order
    is the business idempotency boundary; ``event_key`` protects event insertion.
    """
    if db.bind is not None and db.bind.dialect.name == "postgresql":
        payment = db.scalar(select(Payment).where(Payment.id == payment_public_id).with_for_update())
    else:
        payment = db.get(Payment, payment_public_id)
    if payment is None:
        raise ValueError("unknown payment")
    order = db.get(Order, payment.order_id)
    if order is None:
        raise ValueError("payment order not found")
    plan = db.get(PremiumPlan, order.plan_id)
    user = db.get(User, order.user_id)
    if plan is None or user is None:
        raise ValueError("payment references missing plan/user")
    if authority != payment.provider_authority:
        raise ValueError("payment authority mismatch")

    existing_entitlement = db.scalar(select(Entitlement).where(Entitlement.order_id == order.id))
    if payment.status == "verified":
        if existing_entitlement is None:
            raise RuntimeError("verified payment exists without entitlement")
        return existing_entitlement

    existing_event = db.scalar(select(PaymentEvent).where(PaymentEvent.event_key == event_key))
    if existing_event is not None:
        if existing_entitlement is None:
            raise RuntimeError("idempotency event exists without entitlement")
        return existing_entitlement

    verification = provider.verify_payment(amount_rial=order.amount_minor, authority=authority)
    if not verification.get("verified"):
        payment.status = "failed"
        payment.raw_callback = raw_callback
        payment.verification_response = verification
        order.status = "failed"
        db.add(PaymentEvent(payment_id=payment.id, event_type="verification_failed", event_key=event_key, payload={"provider": provider.name}))
        raise ValueError("payment verification failed")

    if order.amount_minor != plan.price_minor:
        raise ValueError("order/plan amount mismatch")
    if plan.code != PACK_3_TESTS_CODE or plan.credits_granted != PACK_3_CREDITS:
        raise ValueError("unexpected credit-pack configuration")

    paid_at = utcnow()
    snapshot_order_referral(db, order, paid_at=paid_at)
    # Freeze the code's owner and rate onto this order at the same instant the
    # code itself is frozen, so a later ownership change cannot move past
    # commission. The accrual row is then written from that snapshot only.
    snapshot_order_owner(db, order, order.referral_code_snapshot)
    accrue_commission(db, order)

    payment.status = "verified"
    payment.provider_transaction_id = str(verification.get("transaction_id")) if verification.get("transaction_id") else None
    payment.raw_callback = raw_callback
    payment.verification_response = verification
    payment.verified_at = paid_at
    order.status = "paid"
    order.paid_at = paid_at

    entitlement = Entitlement(
        user_id=user.id,
        plan_id=plan.id,
        source="payment",
        credits_granted=plan.credits_granted,
        credits_remaining=plan.credits_granted,
        starts_at=utcnow(),
        expires_at=None,
        status="active",
        order_id=order.id,
    )
    db.add(entitlement)
    db.add(PaymentEvent(payment_id=payment.id, event_type="payment_verified_credits_granted", event_key=event_key, payload={"credits_granted": plan.credits_granted, "plan_code": plan.code}))
    db.flush()
    return entitlement


def consume_one_test(db: Session, user_id: int) -> Entitlement:
    """Consume exactly one test credit from the oldest active entitlement.

    Row locking is used on PostgreSQL to serialize concurrent consumption. The
    operation fails instead of allowing negative credits.

    In BILLING_FREE_MODE consumption is a no-op against quota: users are never
    blocked and remaining credits stay effectively unlimited.
    """
    if is_billing_free_mode():
        entitlement = ensure_free_entitlement(db, user_id)
        return entitlement

    stmt = (
        select(Entitlement)
        .where(
            Entitlement.user_id == user_id,
            Entitlement.status == "active",
            Entitlement.credits_remaining > 0,
        )
        .order_by(Entitlement.created_at.asc(), Entitlement.id.asc())
    )
    if db.bind is not None and db.bind.dialect.name == "postgresql":
        stmt = stmt.with_for_update()

    entitlement = db.scalar(stmt)
    if entitlement is None:
        raise ValueError("no test credits remaining")
    entitlement.credits_remaining -= 1
    db.flush()
    return entitlement
