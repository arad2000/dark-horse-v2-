from __future__ import annotations

import os
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from fastapi.testclient import TestClient

from database import get_db
from main_v2 import app


class FakeDB:
    """Small Session-shaped harness for the production consume-test call path."""

    bind = None

    def __init__(self):
        self._scalar_calls = 0
        self.added = []
        self.deleted = []

    def add(self, instance) -> None:
        self.added.append(instance)

    def commit(self) -> None:
        pass

    def refresh(self, _instance) -> None:
        pass

    def delete(self, instance) -> None:
        self.deleted.append(instance)

    def rollback(self) -> None:
        pass

    def flush(self) -> None:
        pass

    def scalar(self, _statement):
        self._scalar_calls += 1
        if self._scalar_calls == 1:
            return SimpleNamespace(
                id=11,
                public_id="public-11",
                name="Consume User",
                phone="09120000004",
                role="user",
                status="active",
            )
        if self._scalar_calls == 2:
            return SimpleNamespace(user_id=11)
        if self._scalar_calls == 3:
            return None
        return None

    def scalars(self, _statement):
        return [
            SimpleNamespace(
                credits_granted=3,
                credits_remaining=3,
                expires_at=None,
            )
        ]


class FakeSavedSession:
    id = 321
    session_uuid = "sess-123456789"
    is_completed = True


class CommercialApiContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.db = FakeDB()

        def override_get_db():
            yield cls.db

        app.dependency_overrides[get_db] = override_get_db
        cls.client = TestClient(app)

    @classmethod
    def tearDownClass(cls):
        app.dependency_overrides.clear()

    def test_register_starts_phone_verification(self):
        expected = {"otp_required": True, "challenge_id": "challenge-123456", "expires_in": 300, "resend_after": 60}
        with patch("commercial_api.request_registration_otp", return_value=expected) as request_otp:
            response = self.client.post("/api/v1/auth/register", json={"name": "Test User", "phone": "09120000001", "password": "strong-pass-123"})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json(), expected)
        request_otp.assert_called_once_with(
            self.db,
            name="Test User",
            phone="09120000001",
            password="strong-pass-123",
            request_ip="testclient",
            referral_code=None,
        )

    def test_register_forwards_optional_referral_code(self):
        """The referral code is optional and must reach the OTP request as-is."""
        expected = {"otp_required": True, "challenge_id": "challenge-abcdef", "expires_in": 300, "resend_after": 60}
        with patch("commercial_api.request_registration_otp", return_value=expected) as request_otp:
            response = self.client.post(
                "/api/v1/auth/register",
                json={
                    "name": "Test User",
                    "phone": "09120000002",
                    "password": "strong-pass-123",
                    "referral_code": "AHMAD2026",
                },
            )
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(request_otp.call_args.kwargs["referral_code"], "AHMAD2026")

    def test_verify_registration_creates_session_and_free_credit(self):
        user = SimpleNamespace(id=7, public_id="public-7", name="Test User", phone="09120000001", role="user", status="active")
        with patch("commercial_api.verify_registration_otp", return_value=(user, "raw-token")), patch("commercial_api.ensure_free_entitlement"), patch(
            "commercial_api._quota_details",
            return_value={"credits_granted": 1, "credits_consumed": 0, "credits_remaining": 1},
        ):
            response = self.client.post("/api/v1/auth/register/verify", json={"challenge_id": "challenge-123456", "code": "123456"})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["token"], "raw-token")
        self.assertEqual(response.json()["quota"], 1)
        self.assertTrue(response.json()["phone_verified"])

    def test_login_contract(self):
        user = SimpleNamespace(id=8, public_id="public-8", name="Login User", phone="09120000002", role="user", status="active")
        with patch("commercial_api.authenticate_user", return_value=(user, "login-token")), patch("commercial_api.ensure_free_entitlement"), patch(
            "commercial_api._quota_details",
            return_value={"credits_granted": 1, "credits_consumed": 0, "credits_remaining": 1},
        ):
            response = self.client.post("/api/v1/auth/login", json={"phone": user.phone, "password": "strong-pass-123"})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json()["token"], "login-token")
        self.assertEqual(response.json()["quota"], 1)

    def test_bearer_protection_and_me(self):
        user = SimpleNamespace(id=9, public_id="public-9", name="Me User", phone="09120000003", role="user", status="active")
        self.assertEqual(self.client.get("/api/v1/me").status_code, 401)
        with patch("commercial_api.resolve_session", return_value=user):
            response = self.client.get("/api/v1/me", headers={"Authorization": "Bearer token"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["user"]["public_id"], "public-9")

    def test_quota_contract(self):
        user = SimpleNamespace(id=10)
        with patch("commercial_api.resolve_session", return_value=user):
            response = self.client.get("/api/v1/me/quota", headers={"Authorization": "Bearer token"})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.json(),
            {"credits_granted": 3, "credits_consumed": 0, "credits_remaining": 3},
        )

    def test_consume_contract(self):
        user = SimpleNamespace(id=11, public_id="public-11", name="Consume User", phone="09120000004", role="user", status="active")
        entitlement = SimpleNamespace(id=55)
        with patch("commercial_api.resolve_session", return_value=user), patch("commercial_api.consume_one_test", return_value=entitlement), patch(
            "commercial_api._quota_details",
            return_value={"credits_granted": 3, "credits_consumed": 1, "credits_remaining": 2},
        ):
            response = self.client.post(
                "/api/v1/me/consume-test",
                headers={"Authorization": "Bearer token"},
                json={"session_uuid": "sess-123456789"},
            )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["consumed"], 1)
        self.assertEqual(response.json()["credits_remaining"], 2)

    def test_save_result_requires_authentication(self):
        response = self.client.post("/api/v1/me/save-result", json={"session_id": "sess-123456789", "result_summary": {"kind": "majors"}})
        self.assertEqual(response.status_code, 401)

    def test_save_result_contract_and_idempotent_service(self):
        user = SimpleNamespace(id=15, public_id="public-15", name="Result User", phone="09120000005", role="user", status="active")
        expected = {"saved": True, "completed": True, "session_uuid": "sess-123456789", "operational_session_id": 321}
        with patch("commercial_api.resolve_session", return_value=user), patch("api_persistence_adapter.OperationalPersistenceAdapter.save_result", return_value=FakeSavedSession()) as save:
            response = self.client.post(
                "/api/v1/me/save-result",
                headers={"Authorization": "Bearer token"},
                json={"session_uuid": "sess-123456789", "result_summary": {"kind": "majors", "session_uuid": "sess-123456789"}},
            )
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json(), expected)
        save.assert_called_once()
        args = save.call_args.args
        self.assertEqual(args[1], 15)
        self.assertEqual(args[2]["session_uuid"], "sess-123456789")

    def test_save_result_rejects_mismatched_nested_session(self):
        user = SimpleNamespace(id=16)
        with patch("commercial_api.resolve_session", return_value=user):
            response = self.client.post(
                "/api/v1/me/save-result",
                headers={"Authorization": "Bearer token"},
                json={"session_uuid": "sess-123456789", "result_summary": {"session_uuid": "sess-other", "kind": "majors"}},
            )
        self.assertEqual(response.status_code, 409)

    def test_create_payment_is_server_authoritative(self):
        user = SimpleNamespace(id=12)
        expected = {"order_id": "order-12", "payment_id": 77, "provider": "mock", "amount_rial": 2_490_000, "currency": "IRR", "payment_url": "https://sandbox.example.invalid/pay/MOCK-AUTH-001", "authority": "MOCK-AUTH-001"}
        with patch.dict(os.environ, {"BILLING_PROVIDER": "mock"}, clear=False), patch("commercial_api.resolve_session", return_value=user), patch("commercial_api.create_payment_request", return_value=expected) as create:
            response = self.client.post("/api/v1/billing/create-payment", headers={"Authorization": "Bearer token"})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json(), expected)
        kwargs = create.call_args.kwargs
        self.assertEqual(kwargs["user_id"], 12)

    def test_billing_callback_delegates_server_verification_and_redirects(self):
        with patch("commercial_api.handle_payment_callback", return_value={"status": "paid", "order_id": "order-12"}):
            response = self.client.get(
                "/api/v1/billing/callback",
                params={"order_id": "order-12", "Authority": "MOCK-AUTH-001", "Status": "OK"},
                follow_redirects=False,
            )
        self.assertEqual(response.status_code, 303)

    def test_live_zarinpal_requires_explicit_production_approval(self):
        user = SimpleNamespace(id=12)
        with patch.dict(os.environ, {"BILLING_PROVIDER": "zarinpal", "ZARINPAL_PRODUCTION_APPROVED": "false"}, clear=False), patch("commercial_api.resolve_session", return_value=user):
            response = self.client.post("/api/v1/billing/create-payment", headers={"Authorization": "Bearer token"})
        self.assertEqual(response.status_code, 503)

    def test_unknown_billing_provider_fails_closed(self):
        user = SimpleNamespace(id=12)
        with patch.dict(os.environ, {"BILLING_PROVIDER": "unsupported"}, clear=False), patch("commercial_api.resolve_session", return_value=user):
            response = self.client.post("/api/v1/billing/create-payment", headers={"Authorization": "Bearer token"})
        self.assertEqual(response.status_code, 503)


if __name__ == "__main__":
    unittest.main(verbosity=2)
