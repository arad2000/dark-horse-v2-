/* commercial_ui.js — single auth flow + server-authoritative credit gate */
(function (global) {
  'use strict';

  var USER_KEY = 'dh_local_user_v1';
  var QUOTA_KEY = 'dh_local_quota_v1';
  var BUSY = false;
  var QUOTA_SYNC_IN_FLIGHT = null;
  var QUOTA_LAST_SYNC_AT = 0;
  var QUOTA_MIN_INTERVAL_MS = 10000;

  function el(id) { return document.getElementById(id); }
  function text(v) { return String(v == null ? '' : v); }
  function toFa(n) { return String(n == null ? '' : n).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[Number(d)]; }); }
  function digits(v) {
    return text(v).replace(/[۰-۹]/g, function (d) { return String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)); });
  }
  function escapeHtml(v) {
    return text(v).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function saveLocalUser(user) {
    try { localStorage.setItem(USER_KEY, JSON.stringify(user || null)); } catch (_) {}
  }
  function clearLocalState() {
    try { localStorage.removeItem('dh_auth_v1'); } catch (_) {}
    try { localStorage.removeItem(USER_KEY); } catch (_) {}
    try { localStorage.removeItem(QUOTA_KEY); } catch (_) {}
    try { localStorage.removeItem('dh_last_result_v1'); } catch (_) {}
  }
  function setLocalQuota(remaining) {
    try {
      localStorage.setItem(QUOTA_KEY, JSON.stringify({
        used: Number(remaining) > 0 ? 0 : 1,
        premium: false,
        serverRemaining: Math.max(0, Number(remaining) || 0)
      }));
    } catch (_) {}
  }
  function currentJourneySessionId() {
    try {
      var journey = JSON.parse(localStorage.getItem('darkhorse_session_v2') || 'null');
      return journey && journey.sessionId ? String(journey.sessionId) : null;
    } catch (_) { return null; }
  }

  function addStyles() {
    if (el('dh-commercial-styles')) return;
    var s = document.createElement('style');
    s.id = 'dh-commercial-styles';
    s.textContent =
      '.dh-commercial-overlay{position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,.72);display:flex;align-items:center;justify-content:center;padding:18px;backdrop-filter:blur(7px)}' +
      '.dh-commercial-modal{width:100%;max-width:430px;background:#161622;border:1px solid rgba(212,175,55,.45);border-radius:18px;padding:20px;box-shadow:0 20px 60px rgba(0,0,0,.55);color:#eee}' +
      '.dh-commercial-title{color:#f0c040;text-align:center;margin:0 0 8px;font-size:1.35rem}' +
      '.dh-commercial-sub{color:#b0a080;text-align:center;font-size:.86rem;line-height:1.8;margin-bottom:14px}' +
      '.dh-commercial-input{width:100%;padding:12px;border-radius:10px;border:1px solid #333;background:#0f0f18;color:#fff;font:inherit;margin:6px 0;box-sizing:border-box}' +
      '.dh-commercial-actions{display:flex;gap:8px;margin-top:12px}' +
      '.dh-commercial-actions .btn{flex:1;margin:0}' +
      '.dh-commercial-error{color:#ff7b7b;min-height:1.4em;font-size:.82rem;margin-top:6px}' +
      '.dh-commercial-note{color:#8f845f;font-size:.76rem;line-height:1.7;margin-top:10px;text-align:center}' +
      '.dh-commercial-price{font-size:2rem;color:#f0c040;font-weight:800;text-align:center;margin:8px 0}' +
      '.dh-commercial-pack{background:#10101a;border:1px solid rgba(212,175,55,.22);border-radius:12px;padding:12px;margin:12px 0;color:#cbb98a;line-height:2;text-align:center}' +
      '.dh-commercial-link{background:none;border:0;color:#d4af37;text-decoration:underline;cursor:pointer;font:inherit;padding:4px}' +
      '.dh-otp-box{display:flex;gap:8px;justify-content:center;direction:ltr;margin:14px 0}' +
      '.dh-otp-box input{width:44px;height:52px;text-align:center;font-size:1.25rem;font-weight:800}' +
      '.dh-commercial-status{color:#cbb98a;text-align:center;margin:10px 0}';
    document.head.appendChild(s);
  }

  function closeModal() {
    var old = el('dh-commercial-overlay');
    if (old) old.remove();
  }

  function showModal(html) {
    addStyles();
    closeModal();
    var ov = document.createElement('div');
    ov.id = 'dh-commercial-overlay';
    ov.className = 'dh-commercial-overlay';
    ov.innerHTML = '<div class="dh-commercial-modal">' + html + '</div>';
    ov.addEventListener('click', function (e) {
      if (e.target === ov && !BUSY) closeModal();
    });
    document.body.appendChild(ov);
    return ov;
  }

  function showOtpModal(reg) {
    var fields = '';
    for (var i = 1; i <= 6; i += 1) {
      fields += '<input id="dh-otp-' + i + '" class="dh-commercial-input" inputmode="numeric" maxlength="1" autocomplete="one-time-code">';
    }
    var ov = showModal(
      '<h2 class="dh-commercial-title">تأیید شماره موبایل</h2>' +
      '<p class="dh-commercial-sub">کد ۶ رقمی ارسال‌شده به <strong dir="ltr">' + escapeHtml(reg.phone) + '</strong> را وارد کنید.</p>' +
      '<div class="dh-otp-box">' + fields + '</div>' +
      '<div id="dh-otp-err" class="dh-commercial-error"></div>' +
      '<div id="dh-otp-timer" class="dh-commercial-status">اعتبار کد: ۵:۰۰</div>' +
      '<div class="dh-commercial-actions"><button type="button" class="btn btn-primary" id="dh-otp-submit">تأیید و ساخت حساب</button><button type="button" class="btn" id="dh-otp-cancel">انصراف</button></div>' +
      '<p class="dh-commercial-note">کد یک‌بارمصرف ۵ دقیقه معتبر است و تلاش‌های ناموفق محدود هستند.</p>'
    );
    var fieldsList = [];
    for (var j = 1; j <= 6; j += 1) fieldsList.push(el('dh-otp-' + j));
    fieldsList.forEach(function (field, idx) {
      field.addEventListener('input', function () {
        field.value = digits(field.value).replace(/\D/g, '').slice(0, 1);
        if (field.value && fieldsList[idx + 1]) fieldsList[idx + 1].focus();
      });
      field.addEventListener('keydown', function (e) {
        if (e.key === 'Backspace' && !field.value && fieldsList[idx - 1]) fieldsList[idx - 1].focus();
      });
    });
    fieldsList[0].focus();
    var left = Number(reg.expires_in || 300);
    var timer = el('dh-otp-timer');
    var timerId = setInterval(function () {
      left -= 1;
      if (left <= 0) {
        clearInterval(timerId);
        if (timer) timer.textContent = 'کد منقضی شده است.';
      } else if (timer) {
        timer.textContent = 'اعتبار کد: ' + Math.floor(left / 60) + ':' + String(left % 60).padStart(2, '0');
      }
    }, 1000);
    el('dh-otp-cancel').onclick = function () { clearInterval(timerId); closeModal(); };
    el('dh-otp-submit').onclick = async function () {
      if (BUSY) return;
      BUSY = true;
      var err = el('dh-otp-err');
      if (err) err.textContent = '';
      var code = fieldsList.map(function (f) { return f.value; }).join('');
      if (code.length !== 6) {
        if (err) err.textContent = 'کد ۶ رقمی را کامل وارد کنید.';
        BUSY = false;
        return;
      }
      try {
        var data = await global.DHAuth.verifyRegistration(reg.challenge_id, code);
        if (data && data.user) saveLocalUser(data.user);
        if (data && typeof data.quota === 'number') setLocalQuota(data.quota);
        clearInterval(timerId);
        closeModal();
        await continueAfterAuth();
      } catch (e) {
        if (err) err.textContent = text(e && e.message ? e.message : e) || 'تأیید کد ناموفق بود.';
        BUSY = false;
      }
    };
    return ov;
  }

  function showAuthModal(initialMode) {
    var mode = initialMode === 'login' ? 'login' : 'register';
    var ov = showModal('');

    function paint() {
      var title = mode === 'login' ? 'ورود به حساب' : 'ساخت حساب';
      var action = mode === 'login' ? 'ورود' : 'ارسال کد ثبت‌نام';
      ov.querySelector('.dh-commercial-modal').innerHTML =
        '<h2 class="dh-commercial-title">' + title + '</h2>' +
        '<p class="dh-commercial-sub">' + (mode === 'login' ? 'با شماره موبایل و رمز عبور وارد حساب خود شوید.' : 'نام، موبایل و رمز را وارد کنید؛ سپس کد پیامکی کاوه‌نگار را تأیید کنید.') + '</p>' +
        (mode === 'register' ? '<input id="dh-c-name" class="dh-commercial-input" placeholder="نام و نام خانوادگی" autocomplete="name">' : '') +
        (mode === 'register' ? '<input id="dh-c-ref" class="dh-commercial-input" style="direction:ltr;text-align:left;" maxlength="64" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="کد معرف (اختیاری)">' : '') +
        '<input id="dh-c-phone" class="dh-commercial-input" inputmode="numeric" dir="ltr" placeholder="09xxxxxxxxx" autocomplete="tel">' +
        '<input id="dh-c-pass" class="dh-commercial-input" type="password" placeholder="رمز عبور (حداقل ۸ کاراکتر)" autocomplete="current-password">' +
        '<div id="dh-c-err" class="dh-commercial-error"></div>' +
        '<div class="dh-commercial-actions"><button type="button" class="btn btn-primary" id="dh-c-submit">' + action + '</button><button type="button" class="btn" id="dh-c-close">انصراف</button></div>' +
        '<p class="dh-commercial-note">احراز هویت، OTP و اعتبارها در سمت سرور کنترل می‌شوند.</p>' +
        '<div style="text-align:center;margin-top:8px"><button type="button" class="dh-commercial-link" id="dh-c-switch">' + (mode === 'login' ? 'ساخت حساب جدید' : 'حساب دارم؛ ورود') + '</button></div>';

      el('dh-c-close').onclick = closeModal;
      el('dh-c-switch').onclick = function () {
        if (BUSY) return;
        mode = mode === 'login' ? 'register' : 'login';
        paint();
        if (mode === 'login' && typeof global.__dhInstallForgotLink === 'function') global.__dhInstallForgotLink();
      };
      el('dh-c-submit').onclick = async function () {
        if (BUSY) return;
        BUSY = true;
        var err = el('dh-c-err');
        if (err) err.textContent = '';
        var phone = digits(el('dh-c-phone').value).replace(/\s+/g, '');
        var pass = el('dh-c-pass').value;
        var name = mode === 'register' ? el('dh-c-name').value.trim() : '';
        if (mode === 'register' && name.length < 2) { if (err) err.textContent = 'نام را کامل وارد کنید.'; BUSY = false; return; }
        if (!/^09\d{9}$/.test(phone)) { if (err) err.textContent = 'شماره موبایل را به‌صورت 09xxxxxxxxx وارد کنید.'; BUSY = false; return; }
        if (pass.length < 8) { if (err) err.textContent = 'رمز عبور باید حداقل ۸ کاراکتر باشد.'; BUSY = false; return; }
        try {
          if (mode === 'login') {
            var logged = await global.DHAuth.login(phone, pass);
            if (logged && logged.user) saveLocalUser(logged.user);
            if (logged && typeof logged.quota === 'number') setLocalQuota(logged.quota);
            closeModal();
            await continueAfterAuth();
          } else {
            var refInput = el('dh-c-ref');
            var refCode = refInput ? String(refInput.value || '').trim() : '';
            var registration = await global.DHAuth.register(name, phone, pass, refCode);
            if (!registration || !registration.challenge_id) throw new Error('پاسخ OTP ثبت‌نام معتبر نیست.');
            closeModal();
            showOtpModal({ phone: phone, challenge_id: registration.challenge_id, expires_in: registration.expires_in });
          }
        } catch (e) {
          if (err) err.textContent = text(e && e.message ? e.message : e) || 'خطا در ارتباط با سرور.';
        } finally {
          BUSY = false;
        }
      };
    }
    paint();
    if (mode === 'login' && typeof global.__dhInstallForgotLink === 'function') global.__dhInstallForgotLink();
  }

  function openExternalPay(url) {
    if (!url) return false;
    var target = String(url);
    try {
      if (global.AndroidBridge && typeof global.AndroidBridge.openExternalUrl === 'function') {
        global.AndroidBridge.openExternalUrl(target);
        return true;
      }
    } catch (_) {}
    try { window.location.assign(target); return true; } catch (_) {}
    return false;
  }

  function openInviteModal() {
    if (!global.DHAuth || typeof global.DHAuth.isLoggedIn !== 'function' || !global.DHAuth.isLoggedIn()) {
      showAuthModal('login');
      return;
    }
    if (typeof global.DHAuth.myReferralCode !== 'function') {
      showModal('<h2 class="dh-commercial-title">کد معرف شما</h2><p class="dh-commercial-sub">این قابلیت هنوز فعال نشده است.</p>');
      return;
    }
    showModal(
      '<h2 class="dh-commercial-title">کد معرف شما</h2>' +
      '<p class="dh-commercial-sub">این کد را به دوستانت بده. هر کسی با این کد ثبت‌نام کند، به نام تو ثبت می‌شود.</p>' +
      '<div id="dh-invite-body" class="dh-commercial-sub">در حال دریافت کد…</div>' +
      '<div class="dh-commercial-actions"><button type="button" class="btn" id="dh-invite-close">بستن</button></div>'
    );
    el('dh-invite-close').onclick = closeModal;
    global.DHAuth.myReferralCode().then(function (data) {
      var body = el('dh-invite-body');
      if (!body) return;
      if (!data || !data.code) {
        body.textContent = 'کد شما در دسترس نیست.';
        return;
      }
      body.innerHTML =
        '<div style="margin:10px 0;text-align:center;">' +
          '<span id="dh-invite-code" style="display:inline-block;direction:ltr;font-family:ui-monospace,monospace;font-size:1.4rem;letter-spacing:2px;color:#f0c040;background:rgba(240,192,64,.1);border:1px solid rgba(240,192,64,.35);border-radius:10px;padding:8px 16px;">' +
            text(data.code) +
          '</span>' +
        '</div>' +
        '<div style="text-align:center;margin-bottom:8px;">تاکنون ' + toFa(data.signups || 0) + ' نفر با کد شما ثبت‌نام کرده‌اند.</div>' +
        '<div class="dh-commercial-actions"><button type="button" class="btn btn-primary" id="dh-invite-copy">کپی کد</button></div>';
      var copyBtn = el('dh-invite-copy');
      if (copyBtn) {
        copyBtn.onclick = function () {
          var done = function () { copyBtn.textContent = 'کپی شد ✓'; };
          try {
            if (global.navigator && global.navigator.clipboard && global.navigator.clipboard.writeText) {
              global.navigator.clipboard.writeText(data.code).then(done, done);
              return;
            }
          } catch (_) {}
          try {
            var input = el('dh-invite-code');
            var range = document.createRange();
            range.selectNodeContents(input);
            var sel = global.getSelection();
            sel.removeAllRanges(); sel.addRange(range);
            document.execCommand('copy');
            done();
          } catch (_) {}
        };
      }
    }).catch(function (e) {
      var body = el('dh-invite-body');
      if (body) body.textContent = (e && e.message) ? e.message : 'دریافت کد ناموفق بود.';
    });
  }

  function openPurchaseModal() {
    if (!global.DHAuth || typeof global.DHAuth.isLoggedIn !== 'function' || !global.DHAuth.isLoggedIn()) {
      showAuthModal('login');
      return;
    }
    showModal(
      '<h2 class="dh-commercial-title">خرید بسته ۳ تست</h2>' +
      '<div class="dh-commercial-pack"><div class="dh-commercial-price">۲۴۹٬۰۰۰ تومان</div><div>۳ تست · بدون تاریخ انقضا</div></div>' +
      '<div class="dh-referral-entry" style="margin:12px 0 8px;text-align:right;">' +
        '<label class="dh-commercial-label" for="dh-buy-referral-code">کد معرف (اختیاری)</label>' +
        '<input id="dh-buy-referral-code" class="dh-commercial-input dh-referral-input" style="user-select:text;direction:ltr;text-align:left;" type="text" maxlength="64" autocomplete="off" autocapitalize="characters" spellcheck="false" placeholder="کد معرف را وارد کنید" aria-describedby="dh-buy-referral-hint dh-buy-referral-message">' +
        '<p id="dh-buy-referral-hint" style="margin:5px 2px 0;color:#9f957f;font-size:.76rem;line-height:1.7;">کد ندارید؟ این قسمت را خالی بگذارید و ادامه دهید.</p>' +
        '<div id="dh-buy-referral-message" role="status" aria-live="polite" hidden style="margin-top:7px;font-size:.8rem;line-height:1.8;text-align:right;"></div>' +
      '</div>' +
      '<p class="dh-commercial-sub">مبلغ و تعداد اعتبار فقط از سمت سرور تعیین می‌شود.</p>' +
      '<div id="dh-buy-err" class="dh-commercial-error"></div>' +
      '<div class="dh-commercial-actions"><button type="button" class="btn btn-primary" id="dh-buy-now">ادامه به درگاه</button><button type="button" class="btn" id="dh-buy-close">انصراف</button></div>' +
      '<p class="dh-commercial-note">تا زمان فعال‌شدن Merchant، خرید تجاری ممکن است موقتاً غیرفعال باشد.</p>'
    );
    el('dh-buy-close').onclick = closeModal;
    el('dh-buy-now').onclick = async function () {
      if (BUSY) return;
      BUSY = true;
      var err = el('dh-buy-err');
      if (err) err.textContent = '';
      try {
        var referralInput = el('dh-buy-referral-code');
        var referralMsg = el('dh-buy-referral-message');
        var referralCode = referralInput ? String(referralInput.value || '').trim() : '';
        if (referralMsg) { referralMsg.hidden = true; referralMsg.textContent = ''; }
        // Referral attribution is optional and must never block checkout: any
        // failure here (bad code, locked account, network) is reported and the
        // purchase continues as a direct purchase.
        if (typeof global.DHAuth.setReferralCode === 'function') {
          try {
            var referral = await global.DHAuth.setReferralCode(referralCode);
            if (referralMsg && referral && referral.status === 'applied') {
              referralMsg.hidden = false;
              referralMsg.style.color = '#8fe0a8';
              referralMsg.textContent = 'کد معرف ثبت شد.';
            } else if (referralMsg && referralCode) {
              referralMsg.hidden = false;
              referralMsg.style.color = '#f0c040';
              referralMsg.textContent = 'این کد معتبر نبود؛ خرید به‌صورت مستقیم ادامه می‌یابد.';
            }
          } catch (referralError) {
            if (referralMsg && referralCode) {
              referralMsg.hidden = false;
              referralMsg.style.color = '#f0c040';
              referralMsg.textContent = 'ثبت کد معرف انجام نشد؛ خرید به‌صورت مستقیم ادامه می‌یابد.';
            }
          }
        }
        var payment = await global.DHAuth.createPayment();
        if (!payment || !payment.payment_url) throw new Error('آدرس درگاه از سرور دریافت نشد.');
        closeModal();
        openExternalPay(payment.payment_url);
      } catch (e) {
        if (err) err.textContent = text(e && e.message ? e.message : e) || 'ایجاد درخواست پرداخت ناموفق بود.';
        BUSY = false;
      }
    };
  }

  function readJourneyForCommercialGate() {
    try { return JSON.parse(localStorage.getItem('darkhorse_session_v2') || 'null'); }
    catch (_) { return null; }
  }

  function isResumableCommercialJourney() {
    var journey = readJourneyForCommercialGate();
    var stages = ['realm', 'subRealm', 'narrowPath', 'introSwipe', 'swipe',
      'introStrategies', 'strategies', 'introValues', 'values', 'choice'];
    return !!(journey && !journey.journeyFinished && stages.indexOf(journey.stage) >= 0);
  }

  function createCommercialJourneyId() {
    try {
      if (global.crypto && typeof global.crypto.randomUUID === 'function') {
        return global.crypto.randomUUID();
      }
    } catch (_) {}
    return 'dh-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 18);
  }

  function prepareCommercialJourneyId() {
    var journey = readJourneyForCommercialGate();
    var stages = ['realm', 'subRealm', 'narrowPath', 'introSwipe', 'swipe',
      'introStrategies', 'strategies', 'introValues', 'values', 'choice'];
    var resumable = !!(journey && !journey.journeyFinished && stages.indexOf(journey.stage) >= 0);
    var sessionId = resumable && journey.sessionId ? String(journey.sessionId) : createCommercialJourneyId();
    try { localStorage.setItem('dh_pending_journey_session_id', sessionId); } catch (_) {}
    return sessionId;
  }

  async function continueAfterAuth() {
    if (!global.DHAuth || !global.DHAuth.isLoggedIn || !global.DHAuth.isLoggedIn()) {
      showAuthModal('login');
      return;
    }
    var sessionId = null;
    var chargeSucceeded = false;
    try {
      var quota = await global.DHAuth.quota();
      var remaining = Number(quota && quota.credits_remaining || 0);
      setLocalQuota(remaining);
      var resumable = isResumableCommercialJourney();
      if (remaining <= 0 && !resumable) {
        openPurchaseModal();
        return;
      }

      sessionId = prepareCommercialJourneyId();
      var charge = await global.DHAuth.consumeTest(sessionId);
      chargeSucceeded = true;
      var serverRemaining = Number(charge && charge.credits_remaining);
      setLocalQuota(Number.isFinite(serverRemaining) && serverRemaining >= 0
        ? serverRemaining
        : Math.max(0, remaining - (charge && charge.already_consumed ? 0 : 1)));
      closeModal();
      if (global.DHShell && typeof global.DHShell.startJourney === 'function') global.DHShell.startJourney();
    } catch (e) {
      if (sessionId && !chargeSucceeded) {
        try {
          if (localStorage.getItem('dh_pending_journey_session_id') === sessionId) {
            localStorage.removeItem('dh_pending_journey_session_id');
          }
        } catch (_) {}
      }
      var msg = text(e && e.message ? e.message : e);
      if (/401|authentication/i.test(msg)) {
        doLogout(false);
        showAuthModal('login');
        return;
      }
      if (/402|insufficient|quota|credit|سهمیه|اعتبار/i.test(msg)) {
        openPurchaseModal();
        return;
      }
      showModal('<h2 class="dh-commercial-title">خطا</h2><p class="dh-commercial-sub">' + escapeHtml(msg) + '</p><div class="dh-commercial-actions"><button type="button" class="btn btn-primary" id="dh-error-close">باشه</button></div>');
      el('dh-error-close').onclick = closeModal;
    }
  }

  async function persistFinalResultSummary(data, type) {
    if (!data || !global.DHAuth || !global.DHAuth.isLoggedIn || !global.DHAuth.isLoggedIn()) return;
    var sessionId = currentJourneySessionId();
    if (!sessionId || typeof global.DHAuth.saveResult !== 'function') return;
    var summary = {
      type: type === 'branches' ? 'branches' : 'majors',
      session_id: sessionId,
      saved_at: new Date().toISOString(),
      result: data
    };
    try {
      var encoded = JSON.stringify(summary);
      if (new TextEncoder().encode(encoded).length > 100000) {
        summary.result = type === 'branches'
          ? { branch_discovery_result: data.branch_discovery_result || data }
          : { discovery_result: data.discovery_result || data };
      }
      await global.DHAuth.saveResult(summary);
    } catch (e) {
      console.warn('Final result summary persistence skipped:', e);
    }
  }

  function doLogout(reload) {
    try { if (global.DHAuth && typeof global.DHAuth.logout === 'function') global.DHAuth.logout(); } catch (_) {}
    clearLocalState();
    try {
      global.dispatchEvent(new CustomEvent('dh-auth-changed', { detail: { loggedIn: false } }));
    } catch (_) {}
    if (reload !== false) {
      try { global.location.reload(); } catch (_) {}
    }
  }

  function bindButton(id, handler) {
    var button = el(id);
    if (!button || button.__dhCommercialBound) return;
    button.__dhCommercialBound = true;
    button.onclick = function (event) {
      if (event) event.preventDefault();
      handler(event);
    };
  }

  function installButtonHooks() {
    function patch() {
      document.querySelectorAll('#dh-start-journey,#dh-continue-journey,#dh-p-journey').forEach(function (b) {
        if (b.__dhCommercialHooked) return;
        b.__dhCommercialHooked = true;
        b.onclick = function (e) {
          if (e) { e.preventDefault(); e.stopPropagation(); }
          try {
            if (global.DHAuth && typeof global.DHAuth.isLoggedIn === 'function' && global.DHAuth.isLoggedIn()) {
              continueAfterAuth();
              return;
            }
          } catch (_) {}
          showAuthModal('login');
        };
      });
      // Any signed-in user can share their own code. Inserted next to the buy
      // action so it is discoverable without adding a new page.
      var buy = el('dh-p-buy');
      if (buy && buy.parentNode && !el('dh-p-invite')) {
        var invite = document.createElement('button');
        invite.type = 'button';
        invite.className = 'btn';
        invite.id = 'dh-p-invite';
        invite.textContent = 'کد معرف من';
        invite.__dhCommercialHooked = true;
        invite.onclick = function (e) {
          if (e) { e.preventDefault(); e.stopPropagation(); }
          openInviteModal();
        };
        buy.parentNode.insertBefore(invite, buy);
      }
      if (buy && !buy.__dhCommercialHooked) {
        buy.__dhCommercialHooked = true;
        buy.onclick = function (e) {
          if (e) e.preventDefault();
          openPurchaseModal();
        };
      }
      var out = el('dh-p-out');
      if (out && !out.__dhCommercialHooked) {
        out.__dhCommercialHooked = true;
        out.onclick = function (e) {
          if (e) e.preventDefault();
          doLogout();
        };
      }
    }
    patch();
    var _obsT = null;
    new MutationObserver(function () {
      if (_obsT) return;
      _obsT = setTimeout(function () {
        _obsT = null;
        try { patch(); } catch (_) {}
      }, 500);
    }).observe(document.body, { childList: true, subtree: true });
  }

  function syncQuota(done) {
    if (!global.DHAuth || !global.DHAuth.isLoggedIn || !global.DHAuth.isLoggedIn()) {
      if (done) done(null);
      return;
    }
    var now = Date.now();
    if (QUOTA_SYNC_IN_FLIGHT) {
      QUOTA_SYNC_IN_FLIGHT.then(function (value) { if (done) done(value); });
      return;
    }
    if (now - QUOTA_LAST_SYNC_AT < QUOTA_MIN_INTERVAL_MS) {
      var local = null;
      try { local = Number(JSON.parse(localStorage.getItem(QUOTA_KEY) || '{}').serverRemaining); } catch (_) {}
      if (done) done(Number.isFinite(local) ? local : null);
      return;
    }
    QUOTA_LAST_SYNC_AT = now;
    QUOTA_SYNC_IN_FLIGHT = global.DHAuth.quota().then(function (data) {
      var remaining = Math.max(0, Number(data && data.credits_remaining) || 0);
      setLocalQuota(remaining);
      return remaining;
    }).catch(function () {
      return null;
    }).finally(function () {
      QUOTA_SYNC_IN_FLIGHT = null;
    });
    QUOTA_SYNC_IN_FLIGHT.then(function (value) { if (done) done(value); });
  }

  function boot() {
    global.DHCommercialUI = {
      showAuth: showAuthModal,
      showPurchase: openPurchaseModal,
      showInvite: openInviteModal,
      startServerAuthorizedJourney: continueAfterAuth,
      persistFinalResultSummary: persistFinalResultSummary,
      logout: doLogout,
      syncQuota: syncQuota,
      closeModal: closeModal
    };
    installButtonHooks();
    installDiscoverySessionBridge();
    if (document.body && typeof MutationObserver !== 'undefined') {
      var observer = new MutationObserver(function () { installButtonHooks(); });
      observer.observe(document.body, { childList: true, subtree: true });
    }
    // No background quota request on page boot. Quota is fetched after explicit auth/journey actions.
  }

  function installDiscoverySessionBridge() {
    if (global.__dhDiscoverySessionBridgeInstalled || typeof global.fetch !== 'function') return;
    global.__dhDiscoverySessionBridgeInstalled = true;
    var nativeFetch = global.fetch.bind(global);
    global.fetch = async function (input, init) {
      var url = '';
      try { url = typeof input === 'string' ? input : String(input && input.url || ''); } catch (_) {}
      var isDiscovery = /\/api\/v2\/darkhorse\/(discover|branch-discovery)(?:\?|$)/.test(url);
      var isCounsel = /\/api\/v2\/darkhorse\/counsel(?:\?|$)/.test(url);
      var requiresCommercialAuth = isDiscovery || isCounsel;
      var nextInit = init;
      if (requiresCommercialAuth && init && typeof init.body === 'string') {
        try {
          var payload = JSON.parse(init.body);
          var sessionId = currentJourneySessionId();
          if (sessionId && !payload.session_id) {
            payload.session_id = sessionId;
            nextInit = Object.assign({}, init, { body: JSON.stringify(payload) });
          }
        } catch (_) {}
      }
      if (requiresCommercialAuth) {
        try {
          var authState = global.DHAuth && typeof global.DHAuth.getSession === 'function'
            ? global.DHAuth.getSession() : null;
          var token = authState && authState.token;
          if (token) {
            var requestInit = nextInit || {};
            var headers = new Headers(requestInit.headers || {});
            headers.set('Authorization', 'Bearer ' + token);
            nextInit = Object.assign({}, requestInit, { headers: headers });
          }
        } catch (_) {}
      }
      var response = await nativeFetch(input, nextInit);
      if (isDiscovery && response && response.ok) {
        try {
          var body = await response.clone().json();
          if (body && body.session_id) {
            var journey = null;
            try { journey = JSON.parse(localStorage.getItem('darkhorse_session_v2') || 'null'); } catch (_) {}
            journey = journey && typeof journey === 'object' ? journey : {};
            journey.sessionId = String(body.session_id);
            try { localStorage.setItem('darkhorse_session_v2', JSON.stringify(journey)); } catch (_) {}
            if (global.DHCommercialUI && typeof global.DHCommercialUI.persistFinalResultSummary === 'function') {
              try { await global.DHCommercialUI.persistFinalResultSummary(body, /branch-discovery/.test(url) ? 'branches' : 'majors'); } catch (_) {}
            }
          }
        } catch (_) {}
      }
      return response;
    };
  }

  global.DHCommercialUI = {
    showAuth: showAuthModal,
    showPurchase: openPurchaseModal,
    startServerAuthorizedJourney: continueAfterAuth,
    persistFinalResultSummary: persistFinalResultSummary,
    logout: doLogout,
    syncQuota: syncQuota,
    closeModal: closeModal
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})(window);
